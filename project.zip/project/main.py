from ElectricPython import sendJSRequest as js
from ElectricPython import FRONTEND, BACKEND, Window
import time
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
import base64
from io import BytesIO

matplotlib.use('agg')

print(js('console.log("Python is running...")', env=BACKEND))

w = Window(file="./index.html")

def plotFunction(f, domain=(0, 10), range=(0, 10)):
    if f(domain[0]) > range[0]:
        domain = (domain[0], domain[1] - (f(domain[0]) - range[0]))
    if f(domain[1]) > range[1]:
        domain = (domain[0], domain[1]*(domain[1]/f(domain[1])))
    domain = np.linspace(domain[0], domain[1], 1000)
    return domain, [f(x) for x in domain]

def fitData(x, y, func):
    pass

def getData():
    xdata = []
    ydata = []
    for xcell, ycell in zip(w.getElementsByClassName("x-data"), w.getElementsByClassName("y-data")):
        x, y = xcell.textContent, ycell.textContent
        try:
            x = float(x)
            y = float(y)
            xdata.append(x)
            ydata.append(y)
        except ValueError:
            pass
    return xdata, ydata

def plotData():
    xdata, ydata = getData()
    plt.plot(xdata, ydata, 'ro')
#    plt.plot(*plotFunction(lambda x: x**2, domain=(min(xdata), max(xdata)), range=(min(ydata), max(ydata))))
    tmpfile = BytesIO()
    plt.savefig(tmpfile, format='svg')
#    print(tmpfile.getvalue())
    svg = '\n'.join(tmpfile.getvalue().decode('ascii').split("\n")[3:])
    tmpfile.close()
    w.getElementById("graph").innerHTML = svg
    w.js(f"console.log(`{svg}`)")


w.getElementById("plot").addEventListener("click", plotData)

print(js('console.log("Python complete!")', env=BACKEND))
