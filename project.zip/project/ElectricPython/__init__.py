import requests
import json
from xml.etree import ElementTree as ET


DEFAULT_PORT = 3000

FRONTEND = 'frontend'
BACKEND = 'backend'


def sendJSRequest(command, await_result=True, env=FRONTEND, window=-1, port=DEFAULT_PORT):
    if type(command) == list:
        command = "["+",".join(command)+"]"
    url = "http://localhost:" + str(port)
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    if await_result:
        command = '(() => {return ' + command + '})()'
    data = {'cmds': command, 'returndata': str(await_result), 'env':env, 'window':str(window)}
    r = requests.post(url, data=json.dumps(data), headers=headers)
    return r.text


def toJSString(string):
    if type(string) == bool:
        if string:
            return True
        else:
            return False
    elif string is None:
        return "null"
    else:
        return str(string)


def toPyObject(string):
    if (string[0] == '"' and string[-1] == '"') or (string[0] == "'" and string[-1] == "'"):
        string = string[1:-1]
    string = string.replace('\\"', '"')
    if string == "true":
        return True
    elif string == "false":
        return False
    elif string == "null":
        return None
    elif string.isdigit():
        return int(string)
    elif string.replace('.', '', 1).isdigit():
        return float(string)
    else:
        return string



attributes = ['value', 'accept', 'action', 'align', 'allow', 'alt', 'autocapitalize', 'autocomplete',
    'autofocus', 'autoplay', 'buffered', 'capture', 'challenge',
    'charset', 'checked', 'cite', 'code', 'codebase',  'cols', 'colspan',
    'content', 'contenteditable', 'contextmenu', 'controls', 'coords', 'crossorigin', 'csp ',
    'data', 'datetime', 'decoding', 'default', 'defer', 'dir', 'dirname', 'disabled', 'download',
    'draggable', 'enctype', 'enterkeyhint', 'for_', 'form', 'formaction', 'formenctype',
    'formmethod', 'formnovalidate', 'formtarget', 'headers', 'height', 'hidden', 'high', 'href',
    'hreflang', 'http_equiv', 'icon', 'importance', 'integrity', 'intrinsicsize ', 'inputmode',
    'ismap', 'itemprop', 'keytype', 'kind', 'label', 'lang', 'language ', 'loading ', 'list',
    'loop', 'low', 'manifest', 'max', 'maxlength', 'minlength', 'media', 'method', 'min',
    'multiple', 'muted', 'name', 'novalidate', 'open', 'optimum', 'pattern', 'ping', 'placeholder',
    'poster', 'preload', 'radiogroup', 'readonly', 'referrerpolicy', 'rel', 'required', 'reversed',
    'rows', 'rowspan', 'sandbox', 'scope', 'scoped', 'selected', 'shape', 'size', 'sizes', 'slot',
    'span', 'spellcheck', 'src', 'srcdoc', 'srclang', 'srcset', 'start', 'step', 'style',
    'summary', 'tabindex', 'target', 'title', 'translate', 'type', 'usemap', 'width', 'wrap', 'id', 'className']

styles = ['alignContent', 'alignItems', 'alignSelf', 'animation', 'animationDelay', 'animationDirection', 'animationDuration', 'animationFillMode', 'animationIterationCount', 'animationName', 'animationTimingFunction', 'animationPlayState', 'background', 'backgroundAttachment', 'backgroundClip', 'backgroundColor', 'backgroundImage', 'backgroundOrigin', 'backgroundPosition', 'backgroundRepeat', 'backgroundSize', 'backfaceVisibility', 'border', 'borderBottom', 'borderBottomColor', 'borderBottomLeftRadius', 'borderBottomRightRadius', 'borderBottomStyle', 'borderBottomWidth', 'borderCollapse', 'borderColor', 'borderImage', 'borderImageOutset', 'borderImageRepeat', 'borderImageSlice', 'borderImageSource', 'borderImageWidth', 'borderLeft', 'borderLeftColor', 'borderLeftStyle', 'borderLeftWidth', 'borderRadius', 'borderRight', 'borderRightColor', 'borderRightStyle', 'borderRightWidth', 'borderSpacing', 'borderStyle', 'borderTop', 'borderTopColor', 'borderTopLeftRadius', 'borderTopRightRadius', 'borderTopStyle', 'borderTopWidth', 'borderWidth', 'bottom', 'boxShadow', 'boxSizing', 'captionSide', 'caretColor', 'clear', 'clip', 'color', 'columnCount', 'columnFill', 'columnGap', 'columnRule', 'columnRuleColor', 'columnRuleStyle', 'columnRuleWidth', 'columns', 'columnSpan', 'columnWidth', 'counterIncrement', 'counterReset', 'cssFloat', 'cursor', 'direction', 'display', 'emptyCells', 'filter', 'flex', 'flexBasis', 'flexDirection', 'flexFlow', 'flexGrow', 'flexShrink', 'flexWrap', 'font', 'fontFamily', 'fontSize', 'fontStyle', 'fontVariant', 'fontWeight', 'fontSizeAdjust', 'height', 'isolation', 'justifyContent', 'left', 'letterSpacing', 'lineHeight', 'listStyle', 'listStyleImage', 'listStylePosition', 'listStyleType', 'margin', 'marginBottom', 'marginLeft', 'marginRight', 'marginTop', 'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'objectFit', 'objectPosition', 'opacity', 'order', 'orphans', 'outline', 'outlineColor', 'outlineOffset', 'outlineStyle', 'outlineWidth', 'overflow', 'overflowX', 'overflowY', 'padding', 'paddingBottom', 'paddingLeft', 'paddingRight', 'paddingTop', 'pageBreakAfter', 'pageBreakBefore', 'pageBreakInside', 'perspective', 'perspectiveOrigin', 'position', 'quotes', 'resize', 'right', 'scrollBehavior', 'tableLayout', 'tabSize', 'textAlign', 'textAlignLast', 'textDecoration', 'textDecorationColor', 'textDecorationLine', 'textDecorationStyle', 'textIndent', 'textOverflow', 'textShadow', 'textTransform', 'top', 'transform', 'transformOrigin', 'transformStyle', 'transition', 'transitionProperty', 'transitionDuration', 'transitionTimingFunction', 'transitionDelay', 'unicodeBidi', 'userSelect', 'verticalAlign', 'visibility', 'width', 'wordBreak', 'wordSpacing', 'wordWrap', 'widows', 'zIndex']

keywordsPyToJS = {"className": "class"}
keywordsJSToPy = {v: k for k, v in keywordsPyToJS.items()}

def toJSKeyword(string):
    if string in keywordsPyToJS.keys():
        return keywordsPyToJS[string]
    else:
        return string


class Window:
    def __init__(self, html=None, file=None):
        if html:
            self.id = int(sendJSRequest(f'createWindow(800, 600, `{html}`)', await_result=True))
        elif file:
            with open(file, 'r') as f:
                html = f.read()
            self.id = int(sendJSRequest(f'createWindow(800, 600, `{html}`)', await_result=True))
        else:
            self.id = int(sendJSRequest('createWindow(800, 600)', await_result=True))
        self.xml_root = self.getDOM()
        self.elements = []
        self.watched_vars = []
        self.xml_elems = {}
        for val in self.xml_root.iter():
            self.elements.append(HTMLelement(val, self))
            self.xml_elems[val] = self.elements[-1]
        for val in self.xml_elems.keys():
            children = []
            for child in val:
                children.append(self.xml_elems[child])
                self.xml_elems[child].parent = self.xml_elems[val]
            self.xml_elems[val].children = children
        self.body = self.getElementsByTagName("body")[0]

    def js(self, command, await_result=True):
        return sendJSRequest(command, await_result=await_result, window=self.id)

    def close(self):
        sendJSRequest(f'closeWindow({self.id})', await_result=False, env=BACKEND, window=-1)

    def getElementsByTagName(self, tag):
        ret = []
        for e in self.elements:
            if e.tag == tag:
                ret.append(e)
        return ret

    def getElementById(self, id):
        for e in self.elements:
            if e._attrib.get("id", None) == id:
                return e

    def getElementsByClassName(self, className):
        ret = []
        for e in self.elements:
            if e._attrib.get("class", None) == className:
                ret.append(e)
        return ret

    def getElementByUUID(self, uuid):
        for e in self.elements:
            if e.uuid == uuid:
                return e

    def addCallback(self, watched_name, callback_js):
        self.watched_vars.append(watched_name)
        sendJSRequest(f'window.{watched_name} = null;', await_result=False, window=self.id)
        sendJSRequest(callback_js, await_result=False, window=self.id)

    def queryCallback(self, watched_name):
        if watched_name in self.watched_vars:
            return toPyObject(sendJSRequest(f'window.{watched_name}', await_result=True, window=self.id))
        else:
            return None

    def getDOM(self):
        # give each element a unique uuid (separate from the "id" tag) so that Python can tell the difference between elements. Then, create a function to query the DOM by uuid
        # send_JS_request('i=0;for (elem of document.getElementsByTagName("*")){elem.setAttribute("uuid", JSON.stringify(i)); i++; console.log(elem);};document.getElementByUUID = function(uuid){return document.querySelector(`[uuid="${uuid}"]`)};', await_result=True)
        html = f"""<body uuid="{sendJSRequest('document.body.getAttribute("uuid")', window=self.id)[1:-1]}">""" + sendJSRequest('document.body.innerHTML', await_result=True, window=self.id).replace('\\n', '').replace('\\"', '\"').replace("<br>", "\n")[1:-1] + "</body>"
        return ET.fromstring(html)
    
    



class HTMLelement:
    def __init__(self, xml_elem, app):
        self.app = app
        self.win_id = app.id
        self.xml_elem = xml_elem
        self.tag = xml_elem.tag
        self._attrib = xml_elem.attrib
        self.text = xml_elem.text
#        self._children_xml = [HTMLelement(child) for child in xml_elem]
        self.parent = None
        self.uuid = self._attrib.get("uuid", None)
        self.style = self.getAllStyles()
        self.children = []
    
    for attr in attributes:
        exec(f"{attr} = property(lambda self: self.getAttribute('{toJSKeyword(attr)}'), lambda self, value: self.setAttribute('{toJSKeyword(attr)}', value))")

    for style in styles:
        exec(f"{style} = property(lambda self: self.getStyle('{style}'), lambda self, value: self.setStyle('{style}', value))")

    innerHTML = property(lambda self: self.getInnerHTML(), lambda self, value: self.setInnerHTML(value))

    textContent = property(lambda self: self.getText(), lambda self, value: self.setText(value))

    def __repr__(self):
        return self.tag

    def getAttribute(self, attr):
        result = toPyObject(sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").getAttribute("{attr}")', await_result=True, window=self.win_id))
        if result:
            self._attrib.update({attr: result})
        return result

    def setAttribute(self, attr, value):
        value = toJSString(value)
        self._attrib.update({attr: value})
        sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").setAttribute("{attr}", "{value}")', await_result=False, window=self.win_id)

    def getAllStyles(self):
        # TODO: get all styles at once
        return eval(sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").style', await_result=True, window=self.win_id))

    def getStyle(self, style):
        result = toPyObject(sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").style.{style}', await_result=True, window=self.win_id))
        if result:
            self._attrib.update({style: result})
        return result
    
    def setStyle(self, style, value):
        value = toJSString(value)
        self.style.update({style: value})
        sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").style.{style} = "{value}"', await_result=True, window=self.win_id)

    def getInnerHTML(self):
        return toPyObject(sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").innerHTML', await_result=True, window=self.win_id))

    def setInnerHTML(self, value):
        value = toJSString(value)
        self._HTML = value
        sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").innerHTML = "{value}"', await_result=True, window=self.win_id)
    
    def getText(self):
        return toPyObject(sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").textContent', await_result=True, window=self.win_id))
    
    def setText(self, value):
        value = toJSString(value)
        self.text = value
        sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").textContent = "{value}"', await_result=True, window=self.win_id)
    
    def addEventListener(self, event, callback):
        # should take in a valid event name and a callback function with no arguments
        self.app.addCallback(f"{self.tag}{self.uuid}{event}", 'document.body.addEventListener("click", (e) => {window.test = true})')

    def appendNewChild(self, element):
        sendJSRequest(f"elem = document.createElement(\'{element}\')", window=self.win_id, await_result=False)
        sendJSRequest(f'[elem.setAttribute("uuid", JSON.stringify(i)), i++, document.querySelector("[uuid=\'{self.uuid}\']").appendChild(elem)]', await_result=False, window=self.win_id)
        elem = ET.Element(element)
        self.parent.xml_elem.append(elem)

    def insertNewBefore(self, element, before):
        sendJSRequest(f"elem = document.createElement(\'{element}\')", window=self.win_id, await_result=False)
        sendJSRequest(f'[elem.setAttribute("uuid", JSON.stringify(i)), i++, document.querySelector("[uuid=\'{self.uuid}\']").insertBefore(elem, document.querySelector("[uuid=\'{before.uuid}\']"))]', await_result=False, window=self.win_id)

    def destroy(self):
        sendJSRequest(f'document.querySelector("[uuid=\'{self.uuid}\']").remove()', await_result=False, window=self.win_id)

    def getSiblings(self):
        return [child for child in self.parent.children if child != self]

# a.addCallback("test", 'document.getElementById("test").addEventListener("click") = (e) => {window.test = true}')
