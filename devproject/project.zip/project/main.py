from ElectricPython import Window

w = Window(html="<head><title>ElectricPython</title></head><body><h1>ElectricPython</h1><p>ElectricPython is a Python library that allows you to use Python to control desktop applications.</p></body>")